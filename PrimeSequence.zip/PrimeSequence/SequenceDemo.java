/*=============================================================================
|   Source code:  SequenceDemo.java
|        Author:  Jessica Gonzalez
|    Student ID:  6178653
|    Assignment:  Program #5 - Sequence of Primes
|
|        Course:  COP 3337 (Intermediate Programming)
|       Section:  U02
|    Instructor:  William Feild
|      Due Date:  26 March 2019 at 11:00 am
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|
|      Language:  Java
|   Compile/Run:
| 	              javac SequenceDemo.java  PrimeSequence.java
|	              java SequenceDemo argument1 argument2
|
|                argument1: prime sequence will start with the next prime after
|                           this value.
|                argument2: the number of prime numbers to be sequenced.
|
|                Both numbers must be integers and both numbers must be 1
|                or greater.
|
|  +-----------------------------------------------------------------------------
|
|  Description: It produces an arbitrary sequence of n prime numbers in table
|               format and will perform an analysis of those n prime numbers.
|               It gets an array with those prime numbers from PrimeSequence
|               class. Then, it displays a table with all of them and a
|               histogram that show the percent frequency of the las digit [0-9]
|
|
|        Input: Input are provided on the command-line upon execution. Ex:
|               java SequenceDemo 2 25; where the prime sequence will start
|               with the next prime after the first number and the second
|               number is the number of prime numbers to be sequenced. Both
|               numbers must be integers and both numbers must be 1 or greater.
|
|       Output: It provides a table of n prime numbers that is as close to
|               square as possible. More than 100 entries is printed in a
|               table of 10 columns and is not square. Additionally, it
|               includes a histogram for the occurrences of the last digit
|               [0-9] for each prime number. The histogram uses a scale
|               depending of the percentage, where a "*" could represent 1%
|               or 2% approximately. [EXTRA CREDIT] in case of "Integer overflow"
|               prime number is zero.
|
|      Process: 1. It validates that the number of input received is two.
|                  Length of args array should be equal 2 (EXPECTED_LENGTH).
|                  If it is not, display why the input failed and terminate
|                  using System.exit(1).
|               2. It validates that both value are integer and that both
|                  are greater or equal 1. If it is not, display why the input
|                  failed and terminate using System.exit(1).
|               3. Assign both input to two constant variable. START_POINT indicates
|                  where the prime sequence will start (not included).
|                  NUMBER_OF_PRIME indicates the number of prime numbers to be
|                  sequenced. Source: Document Appendix D A-23 textbook
|               4. Creates an object type PrimeSequence that will be used to find
|                  an array with all prime numbers required.
|               5. Call the method of PrimeSequence that return an array of
|                  prime numbers, which is stored in primeNumbers.
|               6. Using countDigits method, count the last digits of each
|                  prime number. Result is saved in array digitsCounter of
|                  size 10, where in position 0 are values ending in 0, in
|                  position 1 values ending in 1, and so on.
|               7. Display a table with all prime numbers of array primeNumbers
|               8. Display a histogram that show a percent o frequency for last
|                  digit of prime numbers found.
|
|   Required Features Not Included:  All required features are included.
|
|   Known Bugs:  When argument2 is a number to close to 2,147,483,647
|                it gives an error "Array out of bound"
|
|*===========================================================================*/

import java.util.Scanner; /*To validate input from command-line*/

public class SequenceDemo
{
	public static final int EXPECTED_LENGTH = 2; /*input provided for command-line*/
	public static final int MAX_PRIME_NUMBERS = 100000000; /*Used in input validation*/
	public static final int DIGITS = 10;         /*amount of different digits[0-9]*/
	public static final int GRAPH_SIZE = 35;     /*Space to print * or white spaces*/
	public static final int HIGH_PERCENT = 70;   /*Used to set a scale */
	public static final int MAX_COLUMNS = 10;    /*Maximum columns in the table*/

	public static void main (String [] args)
	{
		validateLength (args);
		validateInput (args);

		final int START_POINT = Integer.parseInt(args[0]);
		final int NUMBER_OF_PRIME = Integer.parseInt(args[1]);

		PrimeSequence primeSequence = new PrimeSequence(START_POINT, NUMBER_OF_PRIME);

		int [] primeNumbers = primeSequence.getPrimes();
		int [] digitsCounter = countDigits(primeNumbers, NUMBER_OF_PRIME);

		displayHeading(START_POINT,NUMBER_OF_PRIME );
		displayPrimeNumbers (primeNumbers, NUMBER_OF_PRIME);
		displayLastDigitHistogram( NUMBER_OF_PRIME, digitsCounter );
	}

	/*----------------validateLength()-----------------------
	|   Method validateLength()
	|
	|   Purpose: Validates that the length of array args is two
	|            that means two values have been received as
	|            input. If length is different than two, it
	|            display a message and terminate.
	|
	|   @param args
	|
	|   @return none
	*---------------------------------------------------------*/
	public static void validateLength (String [] args)
	{
		if ( args.length != EXPECTED_LENGTH)
		{
			System.out.println("You should enter two number ");
			System.exit(1);
		}
	}

	/*----------------validateInput()-----------------------
	|   Method validateInput()
	|
	|   Purpose: Inside a for loop:
	|            First, creates an object of type Scanner
	|            with the argument that is inside index given
	|            by the for loop. Using hasNextInt() method
	|            check if argument is not an integer, in this
	|            case display a message and terminate. If
	|            it is an integer validate that the number is
	|            greater or equal than 1, if is not, display
	|            a message and terminate. Source:
	|            wiley.com/go/javaexamples Ch11 Section_4
	|            If number of prime numbers is greater than
	|            100,000,000 terminate. According with
	|            https://primes.utm.edu/howmany.html should be
	|            be less than this number for a number less than
	|            2,147,483,647 (maximum integer value)
	|
	|   @param  args
	|
	|   @return none
	*---------------------------------------------------------*/
	public static void validateInput (String [] args)
	{
		for(int index = 0; index < EXPECTED_LENGTH; index ++)
		{
			Scanner in = new Scanner(args[index]);
			if (! in.hasNextInt())
			{
				System.out.println("Input should be an integer");
				System.exit(1);
			}
			else if(Integer.parseInt(args[index]) < 1)
			{
				System.out.println("Both numbers should be greater than 1");
				System.exit(1);
			}
		}

		if( MAX_PRIME_NUMBERS < Integer.parseInt(args[1]) )
		{
			System.out.println("****ERROR*******");
			System.out.println("Number of prime numbers should be smaller");
			System.exit(1);
		}
	}

	/*----------------displayHeading()-----------------------
	|   Method displayHeading()
	|
	|   Purpose: Display heading for table with prime numbers
	|
	|   @param START_POINT
	|   @param NUMBER_OF_PRIME
	|
	|   @return none
	*---------------------------------------------------------*/
	public static void displayHeading(int START_POINT,int NUMBER_OF_PRIME )
	{
		System.out.println("Prime Sequence Table:");
		System.out.printf("Printing a sequence of %d prime numbers, ", NUMBER_OF_PRIME);
		System.out.printf("starting with the first prime after %d %n", START_POINT );
	}

	/*----------------displayPrimeNumbers()-----------------------
	|   Method displayPrimeNumbers()
	|
	|   Purpose:  Display a table with n prime numbers (NUMBER_OF_PRIME)
	|             as close to "square as possible". First, it set a number
	|             of columns for the table using method getColumns. Then,
	|             it creates a variable to keep tracking numbers of columns that
	|             have been printed. Using a for loop print each number that
	|             is inside an array primeNumbers, each time that display a
	|             number, it increments count_columns and when this variable
	|             is equal to the amount of columns set for variable columns, it
	|             print a new line and initializes count_columns to 0.
	|             +Table entries of (0) indicate overflow results [EXTRA CREDIT]
	|
	|   @param  primeNumbers
	|   @param  NUMBER_OF_PRIME
	|
	|   @return none
	*---------------------------------------------------------*/
	public static void displayPrimeNumbers (int [] primeNumbers, int NUMBER_OF_PRIME)
	{
		int columns = getColumns(NUMBER_OF_PRIME);
		int count_columns = 0;

		for (int index = 0; index < NUMBER_OF_PRIME; index ++)
		{
			System.out.printf("%12d",primeNumbers[index]);

			count_columns += 1;

			if ( count_columns == columns )
			{
				System.out.println();
				count_columns = 0;
			}
		}
		System.out.println();
		System.out.println("+Table entries of (0) indicate overflow results \n");
	}

	/*----------------getColumns()-----------------------
	|   Method getColumns()
	|
	|   Purpose: Finds the number of columns for the table
	|            of prime numbers. Using method Math.sqrt()
	|            calculates the square root of the number
	|            of prime numbers to be printed, and this
	|            value is saved as integer. Using "if"
	|            validate if this number does not have perfect
	|            square. When multiplying this integer by itself
	|            should be equal to the original number if it's
	|            a perfect square root. If it's not, columns is
	|            increased by 1 to make the table as close to
	|            square as possible. When number of columns is
	|            greater than the (MAX_COLUMNS) maximum numbers of
	|            columns fixed, it set this variable to the fixed
	|            value.
	|
	|   @param NUMBER_OF_PRIME
	|
	|   @return columns
	*---------------------------------------------------------*/
	public static int getColumns (int NUMBER_OF_PRIME)
	{
		int columns = (int) Math.sqrt(NUMBER_OF_PRIME);

		if ( ( columns * columns ) != NUMBER_OF_PRIME )
		{
			columns += 1;
		}

		if ( columns > MAX_COLUMNS )
		{
			columns = MAX_COLUMNS;
		}
		return columns;
	}


	/*----------------countDigits()-----------------------
	|   Method countDigits()
	|
	|   Purpose: Count last digit of each number and save
	|            the amount in an array where in index 1
	|            are total numbers ending with 1 and in index
	|            3 total numbers ending with 3, for example.
	|            Using a for loop, with NUMBER_OF_PRIME as
	|            length of array that content all prime numbers,
	|            each one is divided by 10 to find a reminder,
	|            which is the last digit. For example reminder
	|            of 15 / 10 is 5 which is the last digit of 15.
	|            An array of size 10, increments by 1 the number
	|            in the index that correspond to the last digit.
	|            The formula used is:
	|
	|            lastDigit = primeNumbers[index] % 10
	|
	|           wiley.com/go/javaexamples Ch10 Worked_example1
	|
	|   @param  primeNumbers
	|   @param  NUMBER_OF_PRIME
	|
	|   @return  counters
	*---------------------------------------------------------*/
	public static int [] countDigits(int[] primeNumbers,int NUMBER_OF_PRIME)
	{
		int [] counters = new int [DIGITS];
		for (int index = 0; index < NUMBER_OF_PRIME; index++)
		{
			int lastDigit = primeNumbers[index] % 10;

			counters[lastDigit]++;
		}
		return counters;
	}

	/*----------------displayLastDigitHistogram()-----------------------
	|   Method displayLastDigitHistogram()
	|
	|   Purpose: Display a histogram for the occurrences of the last
	|            digit [0-9] for each prime number. It's scaled as a
	|            percentage %, with a legend at the bottom to explain
	|            the scale and display the total count of primes.
	|            Fraction percentages are rounded up. Scale value,
	|             and the percentage of each digit are provided
	|            by getPercent() and getScale() methods.
	|            The graph is fixed to a maximum space which is
	|            GRAPH_SIZE = 35. The first "for loop" is to
	|            access the percentage of the last digit, this
	|            number is divided by the scale. For example, if
	|            scale is equal 2 and the % is 50, it will print
	|            25 "*". Then the difference between GRAPH_SIZE
	|            and the number of start that should be printed,
	|            is filled out with white spaces.
	|
	|           starRequired =  digitPercent[index] / scale;
	|           whiteSpaces = GRAPH_SIZE - starRequired
	|
	|           There are two "for loop", one to print required amount
	|           of "*" and another one to print white spaces.
	|
	|   @param NUMBER_OF_PRIME
	|   @param digitsCounter
	|
	|   @return none
	*---------------------------------------------------------*/
	public static void displayLastDigitHistogram( int NUMBER_OF_PRIME, int [] digitsCounter )
	{
		int [] digitPercent = getPercent( digitsCounter, NUMBER_OF_PRIME );
		int totalPercent = 0;
		int scale = getScale(digitPercent);

		System.out.println("Last Digit Histogram:");
		System.out.printf("Scaled as %s, each * = %d%s %n","%", scale, "%");
		System.out.println("Total count may vary slightly from 100% due to rounding percentages \n");

		for(int index = 0; index < DIGITS; index++)
		{
			int starRequired = (int) Math.ceil ( (double) digitPercent[index] / scale);
			int whiteSpaces = GRAPH_SIZE - starRequired;
			totalPercent += digitPercent[index];

			System.out.printf("[%d] ", index);

			for(int star = 0; star < starRequired; star ++ )
			{
				System.out.print("*");
			}

			for(int space = 0; space < whiteSpaces; space ++)
			{
				System.out.print(" ");
			}

			System.out.printf("(%5d, %2d%S) %n", digitsCounter [index], digitPercent[index], "%" );
		}

		System.out.println("_______________________________________________");
		System.out.printf("Total (actual count, %s)        (%d, %d%s) %n","%", NUMBER_OF_PRIME, totalPercent,"%");
		System.out.println("+Histogram entries in (0) row indicates overflow results");
	}

	/*----------------getPercent()-----------------------
	|   Method getPercent()
	|
	|   Purpose: Using an array of size 10, where each index
	|            represent the amount of number ending with
	|            that digit [0-9], it creates another array with
	|            the percentage of each digit. Math.ceil() is
	|            used to round up the percent fraction to the next
	|            integer number. That way, for 1.12 % is rounded
	|            up to 2%.
	|                    digitsCounter[index] * 100
	|          percent = ---------------------------
	|                        NUMBER_OF_PRIME
	|            Math.ceil() return an double and is cast to int
	|            and saved in the new array.
	|
	|   @param digitsCounter
	|   @param NUMBER_OF_PRIME
	|
	|   @return digit_percent
	*---------------------------------------------------------*/
	public static int [] getPercent ( int [] digitsCounter, int NUMBER_OF_PRIME )
	{
		int [] digit_percent = new int [DIGITS];

		for(int index = 0; index < DIGITS; index ++)
		{
			double percent = ( digitsCounter[index] * 100.0 ) /  NUMBER_OF_PRIME ;

			digit_percent[index] = (int) Math.ceil(percent);
		}

		return digit_percent;
	}

	/*----------------getScale()-----------------------
	|   Method getScale()
	|
	|   Purpose: Provides the scale for the histogram.
	|            First, using a for loop, it finds the
	|            higher percentage. Then, using this
	|            value find the scale to be used. When
	|            the percentage is bigger than GRAPH_SIZE
	|            scale is 2, that means "*" stars will be
	|            printed 1-star per 2%. However, if the larger
	|            percent is a bigger number, in this case, bigger
	|            than 70, scale is 3. Otherwise is 1, one star per
	|            each percent.
	|
	|   @param digit_percent
	|
	|   @return scale
	*---------------------------------------------------------*/
	public static int getScale(int [] digit_percent)
	{
		int scale = 1;
		int largePercent = 0;

		for(int index = 0; index < DIGITS; index ++)
		{

			if (digit_percent[index] > largePercent)
			{
				largePercent = digit_percent[index];
			}
		}

		if ( largePercent > GRAPH_SIZE )
		{
			scale = 2;
		}
		if ( largePercent > HIGH_PERCENT )
		{
			scale = 3;
		}
		return scale;
	}

}
