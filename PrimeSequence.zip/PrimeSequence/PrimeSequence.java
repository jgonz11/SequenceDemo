/*=======================================================================
|   Source code:  PrimeSequence.java
|
|         Class:  PrimeSequence
|
|        Author:  Jessica Gonzalez
|    Student ID:  6178653
|    Assignment:  Program #5 - Sequence of Primes
|
|        Course:  COP 3337 (Intermediate Programming)
|       Section:  U02
|    Instructor:  William Feild
|      Due Date:  26 March 2019 at 11:00 am
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|
|      Language:  Java
|   Compile/Run:
| 	                javac PrimeSequence.java
|
|        Purpose:  It finds a sequence of prime numbers using
|                  a value as a start point, where the first
|                  prime after this value will be the first
|                  value of the sequence, and the length of the
|                  sequence will be the amount of desire prime
|                  numbers. It implement the next() method of
|                  the Sequence interface to find the next prime
|                  number to be added to the array of prime found.
|
|  Inherits From:  NONE
|
|
|     Interfaces:  Sequence.java
|
|  +-----------------------------------------------------------------------
|
|      Constants:  final int DEFAULT = 1; This value is used in Constructors
|                                         for the case where no length is
|                                         received.
|                 private final int FIRST_PRIME = 2;   The first prime number
| +-----------------------------------------------------------------------
|
|   Constructors:  public PrimeSequence(int startPoint, int NumberOfPrime)
|                  public PrimeSequence(int startPoint)
|
|  Class Methods:  None
|
|  Instance Methods:  public int next();            return prime;
|                     private boolean isPrime();    return flag;
|                     public int [] getPrimes();    return primeNumbers;
|
*===========================================================================*/

public class PrimeSequence implements Sequence
{
	private final int DEFAULT = 1;
	private final int FIRST_PRIME = 2;
	private int value;
	private int length;

	/*----------------PrimeSequence()-----------------------
	|   Method PrimeSequence()
	|
	|   Purpose: Initialize startPoint to the first value
	|            where prime sequence will start (excluded)
	|            The first prime will be the next prime after
	|            this value.
	|            Initialize length to the number of prime numbers.
	|            This variable will be used as the size of the array
	|            that will store all prime numbers of this sequence.
	|
	|
	|   @param startPoint
	|   @param NumberOfPrime
	|
	|   @return none
	*---------------------------------------------------------*/
	public PrimeSequence(int startPoint, int NumberOfPrime)
	{
		value = startPoint;
		length = NumberOfPrime;
	}

	/*----------------PrimeSequence()-----------------------
	|   Method PrimeSequence()
	|
	|   Purpose: Initialize startPoint to the first value
	|            where prime sequence will start (excluded)
	|            The first prime will be the next prime after
	|            this value.
	|            Initialize length to the DEFAULT ( = 1) value.
	|            This variable will be used as the size of the array
	|            that will store prime numbers of this sequence.
	|            In this case, where no parameters are received
	|            The array is size 1.
	|            It can be use to find a single prime number.
	|
	|   @param startPoint
	|
	|   @return none
	*---------------------------------------------------------*/
	public PrimeSequence(int startPoint)
	{
		value = startPoint;
		length = DEFAULT;
	}

	/*----------------next()-----------------------
	|   Method next()
	|
	|   Purpose: It finds the next prime for a sequence of prime
	|            While the method isPrime() returns false, this
	|            method calls isPrime() with the next value to be
	|            validated as prime or not prime. When "while loop"
	|            ends, "if statement" avoid "Integer overflow", in
	|            this case next() return zero as a prime. Otherwise,
	|            return "prime with the number found" and add 1 to
	|            variable value because successor of every prime number
	|            is always an even number, then when next() method is
	|            called again, value is incremented by 1 and it
	|            passes to isPrime() method a successor of a even
	|            number, which "could" be a prime number. This way
	|            it avoids to check even numbers.
	|            Source: COT3100 FIU Professor Antonio L Bajuelos, Phd
	|            class's materials and:
	| https://www.mkyong.com/java/how-to-determine-a-prime-number-in-java/
	|
	|   @param NONE
	|
	|   @return prime
	*---------------------------------------------------------*/
	public int next()
	{
		int prime = 0;
		do
		{
			value += 1;

		}
		while ( !isPrime() );

		if( value > 0)
		{
			prime = value;
		}

		return prime;
	}

	/*----------------isPrime()-----------------------
	|   Method isPrime()
	|
	|   Purpose: Receives an integer and return true if it's
	|            prime, false otherwise. Inside a for loop, the
	|            value received is divided by all integers
	|            from 2 (first prime) to square root of the value
	|            received. According with both webs listed bellow,
	|            if a number is not prime, we should find a divisor
	|            in a sequence of number from 2 to square root of
	|            this value. Therefore, inside the for loop, if the
	|            reminder is zero that means a divisors was found
	|            and flag is false (is not prime). As Soon as flag is
	|            false, it does not look any other reminder and return
	|            false (number is not prime)
	|
	| https://www.baeldung.com/java-generate-prime-numbers
	| https://www.mkyong.com/java/how-to-determine-a-prime-number-in-java/
	|
	|   @param NONE
	|
	|   @return flag
	*---------------------------------------------------------*/
	private boolean isPrime()
	{
		boolean flag = true;
		int lastNumberToCheck = (int) Math.sqrt(value);

		for(int divisor = FIRST_PRIME; divisor <= lastNumberToCheck ; divisor ++ )
		{
			if ((value % divisor) == 0)
			{
				flag = false;
				divisor = lastNumberToCheck + 1; /*avoid to continue with the loop*/
			}

		}
		return flag;
	}

	/*----------------getPrimes()-----------------------
	|   Method getPrimes()
	|
	|   Purpose: First, it create an array that its size
	|            correspond to the number of prime numbers
	|            of the sequence. "FirstPosition" is initialized
	|            to zero which is the first index. If value is 1,
	|            2 will be the first prime; therefore value is
	|            increased by 1 and 2 is saved in first index of the
	|            array primeNumbers. Now the first position in the
	|            array where primes will be saved is 1, so in the "for loop"
	|            index start at firstPosition continuing until the
	|            length. When the prime received from next() is zero,
	|            indicate overflow results, and return primeNumbers
	|            with prime numbers found and the rest of position
	|            equal to zero (default value).
	|
	|   @param NONE
	|
	|   @return primeNumbers
	*---------------------------------------------------------*/
	public int [] getPrimes()
	{
		int [] primeNumbers = new int [length];
		int firstPosition = 0;

		if (value == 1)
		{
			value += 1;
			primeNumbers [firstPosition] = FIRST_PRIME;
			firstPosition ++;
		}

		for (int index = firstPosition; index < length; index++)
		{
			primeNumbers[index] = next();

			if( primeNumbers[index] == 0)
			{
				return primeNumbers;
			}
		}
		return primeNumbers;
	}
}